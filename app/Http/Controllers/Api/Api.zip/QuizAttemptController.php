<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Quiz;
use App\Models\QuizAttempt;
use App\Models\QuizAttemptAnswer;
use App\Models\Mcq;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class QuizAttemptController extends Controller
{
    // Student ka attempt check karo
    public function checkAttempt($quizId)
    {
        $student = Auth::user();

        $attempt = QuizAttempt::where('student_id', $student->id)
            ->where('quiz_id', $quizId)
            ->first();

        return response()->json([
            'success'  => true,
            'attempted' => $attempt ? true : false,
            'attempt'  => $attempt,
        ]);
    }

    // Quiz start karo — attempt create karo
    public function startQuiz($quizId)
    {
        $student = Auth::user();

        // Already attempted check
        $existing = QuizAttempt::where('student_id', $student->id)
            ->where('quiz_id', $quizId)
            ->first();

        if ($existing) {
            return response()->json([
                'success' => false,
                'message' => 'You have already attempted this quiz.',
                'attempt' => $existing,
            ], 409);
        }

        // Quiz fetch
        $quiz = Quiz::with(['mcqs'])->find($quizId);

        if (!$quiz) {
            return response()->json([
                'success' => false,
                'message' => 'Quiz not found.',
            ], 404);
        }

        // Due date check
        if ($quiz->due_date && now()->gt($quiz->due_date)) {
            return response()->json([
                'success' => false,
                'message' => 'Due date has passed. You cannot attempt this quiz.',
            ], 403);
        }

        // Attempt create karo
        $attempt = QuizAttempt::create([
            'student_id' => $student->id,
            'quiz_id'    => $quizId,
            'status'     => 'pending',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Quiz started successfully.',
            'data'    => [
                'attempt' => $attempt,
                'quiz'    => $quiz,
            ],
        ], 201);
    }

    // Quiz submit karo
    public function submitQuiz(Request $request, $attemptId)
    {
        $request->validate([
            'answers'        => 'required|array',
            'answers.*.mcq_id'        => 'required',
            'answers.*.student_answer' => 'nullable|string',
            'status'         => 'required|in:completed,time_up',
        ]);

        $attempt = QuizAttempt::with('quiz.mcqs')->find($attemptId);

        if (!$attempt) {
            return response()->json([
                'success' => false,
                'message' => 'Attempt not found.',
            ], 404);
        }

        if ($attempt->status !== 'pending') {
            return response()->json([
                'success' => false,
                'message' => 'Quiz already submitted.',
            ], 409);
        }

        DB::beginTransaction();

        try {
            // Answers save karo
            foreach ($request->answers as $answerData) {
                QuizAttemptAnswer::create([
                    'quiz_attempt_id' => $attempt->id,
                    'mcq_id'          => $answerData['mcq_id'],
                    'student_answer'  => $answerData['student_answer'] ?? null,
                ]);
            }

            // Marks calculate karo
            $obtainedMarks = 0;
            $quiz = $attempt->quiz;
            $totalMcqs = $quiz->mcqs->count();

            foreach ($request->answers as $answerData) {
                $mcq = Mcq::where('msq_id', $answerData['mcq_id'])->first();
                if (!$mcq) continue;

                $correctAnswer = strtolower(trim($mcq->answer));
                $studentAnswer = strtolower(trim($answerData['student_answer'] ?? ''));

                if ($studentAnswer === $correctAnswer) {
                    $marksPerQuestion = $totalMcqs > 0
                        ? round($quiz->marks / $totalMcqs)
                        : 0;
                    $obtainedMarks += $marksPerQuestion;
                }
            }

            // Attempt update karo
            $attempt->update([
                'status'         => $request->status,
                'obtained_marks' => null,
                'remarks'        => $request->status === 'time_up'
                    ? 'Time up — auto submitted'
                    : 'Submitted by student',
            ]);

            DB::commit();

            return response()->json([
                'success'        => true,
                'message'        => 'Quiz submitted successfully.',
                'obtained_marks' => null,
                'total_marks'    => $quiz->marks,
                'status'         => $request->status,
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to submit quiz: ' . $e->getMessage(),
            ], 500);
        }
    }

    // Student k attempts list
    public function myAttempts()
    {
        $student = Auth::user();

        $attempts = QuizAttempt::with('quiz')
            ->where('student_id', $student->id)
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data'    => $attempts,
        ]);
    }
}