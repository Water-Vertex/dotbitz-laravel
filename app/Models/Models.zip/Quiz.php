<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Quiz extends Model
{
    protected $fillable = [
        'name',
        'marks',
        'status',
        'duration',
        'course_id',
        'batch_id',
        'due_date',
    ];

    protected $casts = [
        'due_date' => 'datetime',
        'marks'    => 'integer',
        'duration' => 'integer',
    ];

    // Relationships
    public function course()
    {
        return $this->belongsTo(Course::class);
    }

    public function batch()
    {
        return $this->belongsTo(Batch::class);
    }

   public function mcqs()
{
    return $this->belongsToMany(
        Mcq::class,
        'quiz_mcqs',  // pivot table
        'quiz_id',    // quiz_mcqs mein quiz ka column
        'mcq_id',     // quiz_mcqs mein mcq ka column
        'id',         // quizzes table primary key
        'msq_id'      // ✅ mcqs table primary key — msq_id hai mcq_id nahi!
    );
}
}
