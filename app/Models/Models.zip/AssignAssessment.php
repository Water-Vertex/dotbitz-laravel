<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssignAssessment extends Model
{
    protected $fillable = [
        'appointment_id',
        'assessment_id',
        'time_to_complete',
        'total_marks',
        'obtain_marks',
        'remarks',
    ];
public function appointment()
    {
        return $this->belongsTo(Appointment::class);
    }

    public function assessment()
    {
        return $this->belongsTo(Assessment::class);
    }

}
