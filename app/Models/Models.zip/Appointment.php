<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    //
    protected $fillable = [
        'name',
        'email',
        'phone',
        'course_id',
        'appointment_date',
        'appointment_time',
        'message',
    ];

    public function course()
    {
        return $this->belongsTo(Course::class, 'course_id', 'id');
    }

    public function assigned()
    {
        // Relationship name 'assigned' as you requested
        return $this->hasOne(AssignAssessment::class, 'appointment_id');
    }
}
